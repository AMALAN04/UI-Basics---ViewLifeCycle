//
//  staticData.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 26/09/22.
//

import Foundation

class CategoryHelper {
    static let sectionHeaders: [String] = ["Recommended", "Business", "Development", "Design", "Engineering", "Life Style", "Others"]
    
    static func categoryProvider(categoryId: Int) -> Category {
        switch categoryId {
        case 1:
            return .business
        case 2:
            return .development
        case 3:
            return .design
        case 4:
            return .engineering
        case 5:
            return .lifeStyle
        case 6:
            return .others
        default:
            return .others             //result as per search has to be implemented
        }
    }
    
    
//    static func loadData(courseDetails: [CourseDataModel], category: Category) {
//        switch category {
//        case .business:
//            print("B loaded")
//            TableViewCell.businessCourseData = courseDetails
//        case .development:
//            print("DE loaded")
//            TableViewCell.developmentCourseData = courseDetails
//        case .design:
//            print("DS loaded")
//            TableViewCell.designCourseData = courseDetails
//        case .engineering:
//            print("Eg loaded")
//            TableViewCell.engineeringCourseData = courseDetails
//        case .lifeStyle:
//            print("Ly loaded")
//            TableViewCell.lifeStyleCourseData = courseDetails
//        case .others:
//            print("Others REc loaded")
//            TableViewCell.othersCourseData = courseDetails
//            TableViewCell.recommendedCourseData = courseDetails
//
//        }
//    }
    
//    static func categoryLoder(categoryId: Int) -> [CourseDataModel] {
//        let category = CategoryHelper.categoryProvider(categoryId: categoryId)
//        switch category {
//        case .business:
//            print("B ret")
//            return TableViewCell.businessCourseData
//        case .development:
//            print("dde ret")
//            return TableViewCell.developmentCourseData
//        case .design:
//            print("ds ret")
//            return TableViewCell.designCourseData
//        case .engineering:
//            print("eg ret")
//            return TableViewCell.engineeringCourseData
//        case .lifeStyle:
//            print("ly ret")
//            return TableViewCell.lifeStyleCourseData
//        case .others:
//            print("oth ret")
//            return TableViewCell.othersCourseData
//        }
//    }
}
