//
//  File.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 22/09/22.
//

import Foundation

enum Category: Int, CaseIterable {
    case business = 1
    case development
    case design
    case engineering
    case lifeStyle
    case others
    
}
