//
//  Student.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 21/09/22.
//

import Foundation

class Student: User {
     
}
