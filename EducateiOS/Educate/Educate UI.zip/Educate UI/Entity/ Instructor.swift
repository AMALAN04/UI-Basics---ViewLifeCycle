//
//   Instructor.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 22/09/22.
//

import Foundation

class Instructor: User {
    var aboutMe: String = "My lessons are always lively, filled with enjoyable activities and most importantly my lessons are beneficial to my students. I use various teaching methodologies, props, flash cards and a white board to accomplish the desired goal. I make use of Total Physical Response and Communicative Approach to better convey the knowledge to my student."
}
