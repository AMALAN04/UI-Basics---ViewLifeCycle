//
//  MyLearningViewController.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 22/09/22.
//

import UIKit

class MyLearningViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBlue
    }

}
