//
//  ProfileViewController.swift
//  Educate_UI
//
//  Created by amalan-pt5585 on 22/09/22.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemMint
    }
    
}
